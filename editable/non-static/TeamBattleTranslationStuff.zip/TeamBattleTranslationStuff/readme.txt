Locations of text:
teambattle.html: basically everywhere
teambattle.js: lines 74, 158
teamselector.html: basically everywhere
teamselector.js: line 19
csvs: basically everywhere
